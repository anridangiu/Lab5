/*
 * uart_communication.h
 *
 * FSM 2: giao thuc  !RST#  ->  !ADC=xxxx#  ->  !OK#
 * Neu 3 giay khong nhan !OK# thi gui lai goi tin cu (khong doc lai ADC).
 */

#ifndef INC_UART_COMMUNICATION_H_
#define INC_UART_COMMUNICATION_H_

#include "main.h"
#include <stdint.h>

#define UART_TIMEOUT_MS   3000     /* thoi gian cho !OK#                     */
#define UART_PACKET_EOL   "\r\n"   /* ky tu xuong dong sau '#', de "" neu muon
                                      goi tin chi la !ADC=xxxx# (khong xuong dong) */

void uart_communication_fsm(void);

#endif /* INC_UART_COMMUNICATION_H_ */
