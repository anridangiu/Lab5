/*
 * command_parser.h
 *
 * FSM 1: nhan ky tu tu UART (ngat) -> bo dem vong -> tach lenh dang !<CMD>#
 * Lenh hop le: !RST#  (yeu cau du lieu cam bien)
 *              !OK#   (xac nhan da nhan goi tin)
 */

#ifndef INC_COMMAND_PARSER_H_
#define INC_COMMAND_PARSER_H_

#include "main.h"
#include <stdint.h>

#define MAX_BUFFER_SIZE   30   /* kich thuoc bo dem vong nhan UART        */
#define MAX_CMD_SIZE      8    /* do dai toi da cua noi dung lenh (+ '\0') */

/* Gia tri cua command_flag */
#define CMD_NONE          0
#define CMD_RST           1
#define CMD_OK            2

/* ---- Du lieu chia se giua ISR, parser va FSM giao tiep ---- */
extern uint8_t           temp;                      /* 1 byte nhan boi ngat        */
extern uint8_t           buffer[MAX_BUFFER_SIZE];   /* bo dem vong                 */
extern volatile uint8_t  index_buffer;              /* chi so ghi (ISR)            */
extern volatile uint8_t  buffer_flag;               /* =1: co du lieu moi          */

extern volatile uint8_t  command_flag;              /* CMD_NONE / CMD_RST / CMD_OK */
extern uint8_t           command_data[MAX_CMD_SIZE];/* chuoi lenh vua tach duoc    */

void command_parser_init(void);   /* bat ngat nhan UART, goi 1 lan truoc while(1) */
void command_parser_fsm(void);    /* FSM tach lenh, goi trong while(1)            */

#endif /* INC_COMMAND_PARSER_H_ */
