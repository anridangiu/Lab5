/*
 * command_parser.c
 */

#include "command_parser.h"
#include <string.h>

extern UART_HandleTypeDef huart2;

/* ------------------------------------------------------------------ */
/* Du lieu dung chung                                                  */
/* ------------------------------------------------------------------ */
uint8_t          temp = 0;
uint8_t          buffer[MAX_BUFFER_SIZE];
volatile uint8_t index_buffer = 0;   /* head: ISR ghi vao      */
volatile uint8_t buffer_flag  = 0;

volatile uint8_t command_flag = CMD_NONE;
uint8_t          command_data[MAX_CMD_SIZE];

static uint8_t   read_index = 0;     /* tail: parser doc ra    */

/* ------------------------------------------------------------------ */
/* Trang thai cua FSM tach lenh                                        */
/* ------------------------------------------------------------------ */
typedef enum {
    PARSER_WAIT_START,   /* cho ky tu '!'                               */
    PARSER_READ_BODY     /* dang doc noi dung lenh, cho ky tu '#'       */
} ParserState;

static ParserState parser_state = PARSER_WAIT_START;
static uint8_t     cmd_len = 0;

/* ------------------------------------------------------------------ */
/* Ngat nhan UART: chi them ky tu vao bo dem va bat co                  */
/* ------------------------------------------------------------------ */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) {
        uint8_t next = (uint8_t)((index_buffer + 1) % MAX_BUFFER_SIZE);
        if (next != read_index) {            /* bo dem day thi bo ky tu */
            buffer[index_buffer] = temp;
            index_buffer = next;
        }
        buffer_flag = 1;
        HAL_UART_Receive_IT(&huart2, &temp, 1);
    }
}

/* Neu co loi UART (overrun, noise...) thi bat lai ngat nhan */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) {
        HAL_UART_Receive_IT(&huart2, &temp, 1);
    }
}

void command_parser_init(void)
{
    parser_state = PARSER_WAIT_START;
    cmd_len      = 0;
    read_index   = 0;
    index_buffer = 0;
    buffer_flag  = 0;
    command_flag = CMD_NONE;
    HAL_UART_Receive_IT(&huart2, &temp, 1);
}

/* So khop chuoi lenh da tach duoc, dat command_flag tuong ung */
static void command_match(void)
{
    command_data[cmd_len] = '\0';

    if (strcmp((char *)command_data, "RST") == 0) {
        command_flag = CMD_RST;
    } else if (strcmp((char *)command_data, "OK") == 0) {
        command_flag = CMD_OK;
    }
    /* lenh la: bo qua */
}

/* ------------------------------------------------------------------ */
/* FSM tach lenh: xu ly lan luot tung ky tu trong bo dem               */
/* ------------------------------------------------------------------ */
void command_parser_fsm(void)
{
    buffer_flag = 0;   /* xoa co truoc khi doc de khong mat ky tu den sau */

    /* Dung lai khi da co 1 lenh chua duoc FSM giao tiep xu ly, ky tu con
       lai nam yen trong bo dem va se duoc doc o lan sau. */
    while (read_index != index_buffer && command_flag == CMD_NONE) {
        uint8_t c = buffer[read_index];
        read_index = (uint8_t)((read_index + 1) % MAX_BUFFER_SIZE);

        switch (parser_state) {
        case PARSER_WAIT_START:
            if (c == '!') {
                cmd_len = 0;
                parser_state = PARSER_READ_BODY;
            }
            break;

        case PARSER_READ_BODY:
            if (c == '!') {                       /* gap '!' moi: bat dau lai */
                cmd_len = 0;
            } else if (c == '#') {                /* ket thuc lenh            */
                command_match();
                parser_state = PARSER_WAIT_START;
            } else if (cmd_len < MAX_CMD_SIZE - 1) {
                command_data[cmd_len++] = c;
            } else {                              /* qua dai: bo lenh         */
                parser_state = PARSER_WAIT_START;
            }
            break;

        default:
            parser_state = PARSER_WAIT_START;
            break;
        }
    }

    if (read_index != index_buffer) {
        buffer_flag = 1;   /* con ky tu chua doc, lan sau doc tiep */
    }
}
