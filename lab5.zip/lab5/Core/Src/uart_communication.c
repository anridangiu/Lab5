/*
 * uart_communication.c
 */

#include "uart_communication.h"
#include "command_parser.h"
#include <stdio.h>

extern ADC_HandleTypeDef  hadc1;
extern UART_HandleTypeDef huart2;

typedef enum {
    UART_IDLE,      /* cho !RST# tu terminal                         */
    UART_SEND,      /* gui (hoac gui lai) goi tin !ADC=xxxx#         */
    UART_WAIT_OK    /* cho !OK#, het 3s thi quay lai UART_SEND       */
} UartState;

static UartState uart_state = UART_IDLE;
static uint32_t  ADC_value  = 0;
static uint32_t  time_sent  = 0;
static char      str[24];

/* Doc 1 mau ADC1 (PA0), che do polling */
static uint32_t adc_read(void)
{
    uint32_t value = ADC_value;               /* loi thi giu gia tri cu */

    HAL_ADC_Start(&hadc1);
    if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK) {
        value = HAL_ADC_GetValue(&hadc1);
    }
    HAL_ADC_Stop(&hadc1);
    return value;
}

static void packet_send(void)
{
    int len = snprintf(str, sizeof(str), "!ADC=%lu#" UART_PACKET_EOL,
                       (unsigned long)ADC_value);
    HAL_UART_Transmit(&huart2, (uint8_t *)str, (uint16_t)len, 1000);
}

void uart_communication_fsm(void)
{
    switch (uart_state) {

    case UART_IDLE:
        if (command_flag == CMD_RST) {
            command_flag = CMD_NONE;
            ADC_value    = adc_read();        /* chot gia tri 1 lan duy nhat */
            uart_state   = UART_SEND;
        } else if (command_flag != CMD_NONE) {
            command_flag = CMD_NONE;          /* !OK# khi chua gui gi: bo qua */
        }
        break;

    case UART_SEND:
        packet_send();
        time_sent  = HAL_GetTick();
        uart_state = UART_WAIT_OK;
        break;

    case UART_WAIT_OK:
        if (command_flag == CMD_OK) {
            command_flag = CMD_NONE;
            uart_state   = UART_IDLE;         /* ket thuc phien giao tiep */
        } else if (command_flag != CMD_NONE) {
            command_flag = CMD_NONE;          /* !RST# trong luc dang cho: bo qua */
        } else if ((HAL_GetTick() - time_sent) >= UART_TIMEOUT_MS) {
            uart_state = UART_SEND;           /* timeout: gui lai goi tin cu */
        }
        break;

    default:
        uart_state = UART_IDLE;
        break;
    }
}
